<?php
declare(strict_types=1);

/**
 * Konfigurasi utama aplikasi.
 * Sesuaikan nilai database di bawah ini setelah upload ke cPanel.
 */

date_default_timezone_set('Asia/Makassar');

define('APP_NAME', 'Portal Kelulusan MTsN 1 Pohuwato');
define('APP_SCHOOL', 'MTs Negeri 1 Pohuwato');
define('APP_YEAR', '2025/2026');
define('APP_TIMEZONE', 'Asia/Makassar');
define('APP_BASE_URL', '');

define('DB_HOST', 'localhost');
define('DB_NAME', 'mtst2537_pengumuman');
define('DB_USER', 'mtst2537_pengumuman');
define('DB_PASS', 'pengumuman1234');
define('DB_CHARSET', 'utf8mb4');

function pdo(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        exit('Aplikasi belum dapat terhubung ke database. Periksa konfigurasi database Anda.');
    }

    return $pdo;
}
